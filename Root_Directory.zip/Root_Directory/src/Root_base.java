/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author setia1
 */
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class Root_base extends javax.swing.JFrame {

    String old;

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(Root_base.class.getName());

    /**
     * Creates new form Root_base
     */
    public Root_base() {
        initComponents();
        jTextArea1.setText("Select any File to view");
        seedrive();

    }

    private void seedrive() {
        File[] drives = File.listRoots();
        System.out.println("Available Drives:");
        try {
            jComboBox1.removeAll();
            jComboBox1.addItem("Choose Disk");
            for (File drive : drives) {
                System.out.println(drive);
                jComboBox1.addItem(drive.getPath());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setPath(String lastPath) {
        jTextField1.setText(lastPath);
        File folderr = new File(lastPath);
        String[] filelist = folderr.list();
        DefaultListModel<String> model = new DefaultListModel();
        for (String fileName : filelist) {
            model.addElement(fileName);
            System.out.println(fileName);
        }
        jList1.setModel(model);
    }

    private void openFile(String lastPath, String oldPath) {
        File check = new File(lastPath);
        if (!check.canRead()) {
            jTextArea1.setText("Can't Open this, Access is denied");
            System.out.println(lastPath + "    " + oldPath);
            jTextField1.setText(oldPath);
            return;
        }
        try (BufferedReader br = new BufferedReader(new FileReader(lastPath))) {

            jTextArea1.setText("");
            String line;
            while ((line = br.readLine()) != null) {
                jTextArea1.append(line + "\n");
                System.out.println(line);
            }
        } catch (IOException ex) {
            jTextArea1.setText("Unable to read file");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void updatedir() {
        String path = jTextField1.getText();
        File folder = new File(path);
        String[] fileList = folder.list();
        System.out.println("FILES:");
        DefaultListModel<String> model = new DefaultListModel();
        for (String fileName : fileList) {
            model.addElement(fileName);
            System.out.println(fileName);
        }
        jList1.setModel(model);

    }

    private void deletefolder(String Folder) {
        System.out.println(Folder);
        File folder = new File(Folder);
        String[] fileList = folder.list();
        System.out.println("FILES:");
        for (String fileName : fileList) {
            fileName = folder + "\\" + fileName;

            File nestedpath = new File(fileName);
            if (nestedpath.isDirectory()) {
                File FOLDER = new File(fileName);
                deletefolder(fileName);

            }
            System.out.println(nestedpath.getPath());
            nestedpath.delete();

        }
    }

    private void goback() {
        String old = jTextField1.getText();
        char[] chars = old.toCharArray();
        int j = 0, count = 0;
        int i = 0;
        for (i = 0; i < chars.length; i++) {

            if (chars[i] == '\\') {
                count++;
                j = i;
            }
        }
        if (j == 2) {
            JOptionPane.showMessageDialog(null, "Can't go Back");
            return;
        }
        String newPath = new String(chars, 0, j);
        System.out.println(newPath);
        setPath(newPath);
    }

    private void gobackException(String outer) {
        System.out.println("Entered in exception");
        String old = jTextField1.getText();
        System.out.println(outer+"  "+old);
        char[] chars = old.toCharArray();
        int j = 0, count = 0;
        int i = 0;
        for (i = 0; i < chars.length; i++) {

            if (chars[i] == '\\') {
                count++;
                j = i;
            }
        }
        
        if (j == 2) {
            JOptionPane.showMessageDialog(null, "Can't go Back");
            return;
        }
        String newPath = new String(chars, 0, j);
        System.out.println(newPath);
        jTextField1.setText(newPath);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jTextField2 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Disk Management");

        jPanel1.setBackground(new java.awt.Color(102, 153, 255));

        jComboBox1.addActionListener(this::jComboBox1ActionPerformed);

        jTextField1.setEditable(false);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jList1.addListSelectionListener(this::jList1ValueChanged);
        jScrollPane3.setViewportView(jList1);

        jButton1.setText("Back");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jButton2.setText("New Folder");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        jButton3.setText("Delete");
        jButton3.addActionListener(this::jButton3ActionPerformed);

        jButton4.setText("Clear");
        jButton4.addActionListener(this::jButton4ActionPerformed);

        jButton5.setText("Save");
        jButton5.addActionListener(this::jButton5ActionPerformed);

        jPanel2.setVisible(false);
        jPanel2.setBackground(new java.awt.Color(102, 153, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel1.setText("Enter Folder name");

        jButton7.setText("Create Folder");
        jButton7.addActionListener(this::jButton7ActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(105, 105, 105)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(172, 172, 172))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(217, 217, 217)
                .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addComponent(jButton7, javax.swing.GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE))
        );

        jButton6.setText("New File");
        jButton6.addActionListener(this::jButton6ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 364, Short.MAX_VALUE)
                            .addComponent(jTextField1, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(49, 49, 49)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(42, 42, 42)
                        .addComponent(jButton2)
                        .addGap(49, 49, 49)
                        .addComponent(jButton6)
                        .addGap(50, 50, 50)
                        .addComponent(jButton4)
                        .addGap(39, 39, 39)
                        .addComponent(jButton5)
                        .addGap(36, 36, 36)
                        .addComponent(jButton3)
                        .addContainerGap(12, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(34, 34, 34)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 236, Short.MAX_VALUE))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton4)
                    .addComponent(jButton5)
                    .addComponent(jButton3)
                    .addComponent(jButton6)
                    .addComponent(jButton2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel3.setVisible(false);
        jPanel3.setBackground(new java.awt.Color(102, 153, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Enter File Name");

        jButton8.setText("Create File");
        jButton8.addActionListener(this::jButton8ActionPerformed);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(133, 133, 133)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setEditable(true);
        String path = (String) jComboBox1.getSelectedItem();

        if (path.equals("Choose Disk")) {
            return;
        }
        System.out.println(path);
        File folder = new File(path);
        jTextField1.setText(folder.getPath());
        String newPath = folder.getPath() + "\\";
        System.out.println(newPath);
        old = newPath;

        File folderr = new File(newPath);
        String[] fileList = folderr.list();
        System.out.println("Files:");
        DefaultListModel<String> model = new DefaultListModel();
        for (String fileName : fileList) {
            model.addElement(fileName);
            System.out.println(fileName);
        }
        jList1.setModel(model);
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void jList1ValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_jList1ValueChanged
        // TODO add your handling code here:
        jTextArea1.setEditable(true);
        jTextArea1.setText("Select any File to view");
        String outer = jTextField1.getText();
        if (evt.getValueIsAdjusting()) {
            return;
        }

        String inner = jList1.getSelectedValue();
        if (inner == null) {
            return;
        }
        String lastPath = outer + "\\" + inner;
        File folderr = new File(lastPath);

        
        System.out.println(inner);
        ArrayList<String> img = new ArrayList<>();
        img.add(".png");
        img.add(".jpg");
        img.add(".jpeg");
        img.add(".gif");
        ArrayList<String> filess = new ArrayList<>();

// Plain text
        filess.add(".txt");
        filess.add(".log");
        filess.add(".csv");

// Source code
        filess.add(".java");
        filess.add(".c");
        filess.add(".cpp");
        filess.add(".h");
        filess.add(".hpp");
        filess.add(".py");
        filess.add(".js");
        filess.add(".ts");
        filess.add(".cs");
        filess.add(".go");
        filess.add(".rs");
        filess.add(".kt");
        filess.add(".swift");

// Web
        filess.add(".html");
        filess.add(".htm");
        filess.add(".css");
        filess.add(".php");
        filess.add(".jsp");
        filess.add(".asp");
        filess.add(".aspx");

// Markup & Config
        filess.add(".xml");
        filess.add(".json");
        filess.add(".yaml");
        filess.add(".yml");
        filess.add(".ini");
        filess.add(".conf");
        filess.add(".properties");

// Database/SQL
        filess.add(".sql");

// Documentation
        filess.add(".md");
        filess.add(".rtf");

        int found = 0;
        for (String check : img) {
            if (inner.endsWith(check)) {
                found = 1;
                System.out.println("Image found");
            }
        }
        int operate = 0;
        for (String filecheck : filess) {
            if (inner.endsWith(filecheck)) {
                operate = 1;
                System.out.println("File found");
            }
        }
        if (found != 0) {
            jTextArea1.setText("You can't view your image here.");
            jTextArea1.setEditable(false);
        } else {
            if (folderr.isDirectory()) {
                try {
                    setPath(lastPath);
                } catch (NullPointerException e) {
                    jTextArea1.setText("Unable to open this folder");
                    jTextArea1.setEditable(false);
                    gobackException(outer);
                }

                
            } else {
                if (operate == 0) {
                    jTextArea1.setText("No permission to view this file,but deletion is possible.");
                    jTextArea1.setEditable(false);
                    return;
                } else {

                    openFile(lastPath, outer);
                }
            }
        }
    }//GEN-LAST:event_jList1ValueChanged

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        // TODO add your handling code here:
        String line=jTextArea1.getText();
        if(line.equals("No permission to view this file,but deletion is possible.")){
            JOptionPane.showMessageDialog(null, "Permission denied,Can't perform this operation");
            return;
        }
        jTextArea1.setEditable(true);
        if ((jTextField1.getText()).equals("")) {
            JOptionPane.showMessageDialog(null, "Open a file first");
            return;
        }

        String inner = jTextField1.getText();
        String outer = jList1.getSelectedValue();
        if (outer == null) {
            JOptionPane.showMessageDialog(null, "Open a file first");
            return;
        }

        String path = inner + "\\" + outer;
        File folder = new File(path);
        try (FileWriter writer = new FileWriter(path)) {
            if (folder.isFile()) {
                String data = jTextArea1.getText();
                writer.write(data);
                JOptionPane.showMessageDialog(null, "Data inserted successfully");
            } else {
                JOptionPane.showMessageDialog(null, "This is not a file");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setEditable(true);
        if ((jTextField1.getText()).equals("")) {
            JOptionPane.showMessageDialog(null, "Enter into a disk first");
            this.pack();
            return;
        }
        jPanel2.setVisible(true);
        this.pack();
        String path = jTextField1.getText();
        jTextArea1.setText("------Creating new Folder------");
        System.out.println(path);

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setEditable(true);
        if ((jTextField1.getText()).equals("")) {
            JOptionPane.showMessageDialog(null, "Enter into a disk first");
            this.pack();
            return;
        }
        jTextArea1.setText("Demo Data");
        jPanel3.setVisible(true);
        this.pack();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setEditable(true);

        if ((jTextField1.getText()).equals("")) {
            JOptionPane.showMessageDialog(null, "Enter into a disk first");
            jPanel2.setVisible(false);
            jPanel3.setVisible(false);
            this.pack();
            return;
        }

        if ((jTextField2.getText()).equals("")) {
            JOptionPane.showMessageDialog(null, "Enter folder name first");
            return;
        }
        String newouter = jTextField2.getText();
        //System.out.println(newouter);
        String newinner = jTextField1.getText();
        String foldername = newinner + "\\" + newouter;
        System.out.println(foldername);
        File folder = new File(foldername);
        if (folder.exists()) {
            JOptionPane.showMessageDialog(null, "Folder/File already exists.Choose another name");
            jTextField2.setText("");
            return;
        } else {
            folder.mkdir();
            JOptionPane.showMessageDialog(null, "Folder Created Successfully!!");
            updatedir();
            jTextField2.setText("");
        }
        jPanel2.setVisible(false);
        this.pack();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setEditable(true);

        if ((jTextField3.getText()).equals("")) {
            JOptionPane.showMessageDialog(null, "Enter file name first");
            return;
        }

        String abd = jTextField3.getText();
        String inner = jTextField1.getText();
        String newfile = inner + "\\" + abd;
        System.out.println(newfile);
        String data = jTextArea1.getText();
        System.out.println(data);
        try (FileWriter writer = new FileWriter(newfile)) {
            writer.write(data);
        } catch (Exception e) {
            e.printStackTrace();
        }
        JOptionPane.showMessageDialog(null, "File created successfully");
        updatedir();
        jPanel2.setVisible(false);
        jTextField3.setText("");
        jPanel3.setVisible(false);
        this.pack();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setEditable(true);
        String outerchange = jTextField1.getText();
        String innerchange = jList1.getSelectedValue();
        String path = outerchange + "\\" + innerchange;
        System.out.println(path);
        File folder = new File(path);
        if (folder.isFile()) {
            JOptionPane.showMessageDialog(null, "Enter new data in this file");
            System.out.println("You can now change text in file");
            jTextArea1.setText("");
        } else {
            JOptionPane.showMessageDialog(null, "Open a file first");
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setEditable(true);

        String Folder = jTextField1.getText();
        if (Folder.startsWith("C")) {
            JOptionPane.showMessageDialog(null, "Due to security reasons,no deletion possible in C Drive");
            return;
        }

        if ((jTextField1.getText()).equals("")) {
            JOptionPane.showMessageDialog(null, "Enter into a disk first");
            return;
        }
        String toDelete = jList1.getSelectedValue();
        if (toDelete == null) {
            
            deletefolder(Folder);
            File FOLDER = new File(Folder);
            boolean deletedsuccess = FOLDER.delete();
            if (deletedsuccess) {
                JOptionPane.showMessageDialog(null, "Folder deleted successfully");
                goback();
            } else {
                JOptionPane.showMessageDialog(null, "Error while deletion");
            }

        } else {
            String outer = jTextField1.getText();
            String deletion = outer + "\\" + toDelete;
            System.out.println(deletion);
            File del = new File(deletion);
            System.out.println(del);
            boolean deleted = del.delete();
            if (deleted) {
                JOptionPane.showMessageDialog(null, "File deleted successfully");
                updatedir();
            } else {
                JOptionPane.showMessageDialog(null, "Error while deletion");
            }
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        jTextArea1.setEditable(true);
        if ((jTextField1.getText()).equals("")) {
            JOptionPane.showMessageDialog(null, "Enter into a disk first");
            return;
        }
        goback();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new Root_base().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JList<String> jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    // End of variables declaration//GEN-END:variables
}
